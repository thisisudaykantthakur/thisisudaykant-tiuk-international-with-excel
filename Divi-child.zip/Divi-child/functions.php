<?php
function my_theme_enqueue_styles() {
    wp_enqueue_style( 'divi-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'divi-style' ), wp_get_theme()->get('Version') );
}
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );

 
//you can add custom functions below this line:

/******** Remove checkout fields *********/
add_filter( 'woocommerce_checkout_fields' , 'custom_override_checkout_fields' );

function custom_override_checkout_fields( $fields ) {
 // remove billing fields

	unset($fields['billing']['billing_company']); // Billing company
	unset($fields['billing']['billing_address_1']); // Billing Address 1
	unset($fields['billing']['billing_address_2']); // Billing Address 2
	unset($fields['billing']['billing_state']); // Billing state
	unset($fields['billing']['billing_city']); // billing_city
	unset($fields['billing']['billing_postcode']); // billing_postcode
	unset($fields['billing']['billing_first_name']); // billing_first_name
	unset($fields['billing']['billing_last_name']); // billing_last_name
	unset($fields['billing']['billing_phone']); // billing_first_name
	unset($fields['billing']['billing_email']); // billing_last_name


	// remove order comment fields
   	unset($fields['order']['order_comments']); // Order comments
   
     return $fields;
}

/****** Frontend: Display the custom billing fields (in checkout and my account) ***add new fields ********/
add_filter( 'woocommerce_billing_fields' ,'add_custom_billing_fields', 20, 1 );
function add_custom_billing_fields( $fields ) {

    $fields['billing_your_name'] = array(
        'label' => __( 'Your name', 'woocommerce' ),
        'placeholder'   => _x('Enter your name', 'placeholder', 'woocommerce'),
        'required'  => true,
        'class'     => array('form-row-wide form-row-wide-your-name'),
        'clear'     => true
    );

    $fields['billing_your_phone'] = array(
        'label' => __( 'Your phone', 'woocommerce' ),
        'placeholder'   => _x('Enter your phone number', 'placeholder', 'woocommerce'),
        'required'  => true,
        'class'     => array('form-row-wide'),
        'clear'     => true
    );

    $fields['billing_your_mail'] = array(
        'label' => __( 'Your email', 'woocommerce' ),
	'type'	=> 'email',
        'placeholder'   => _x('Enter your account number', 'placeholder', 'woocommerce'),
        'required'  => true,
        'class'     => array('form-row-wide'),
        'clear'     => true
    );

    $fields['billing_bank_account_number'] = array(
        'label' => __( 'Account number', 'woocommerce' ),
        'placeholder'   => _x('Enter your account number', 'placeholder', 'woocommerce'),
        'required'  => true,
        'class'     => array('form-row-wide'),
        'clear'     => true
    );

    $fields['billing_bank_IFSC_code'] = array(
        'label' => __( 'Bank IFSC', 'woocommerce' ),
        'placeholder'   => _x('Enter acconunt ifsc', 'placeholder', 'woocommerce'),
        'required'  => true,
        'class'     => array('form-row-wide'),
        'clear'     => true
    );

    return $fields;
}

/******** Save the custom billing fields (once order is placed) *********/

add_action( 'woocommerce_checkout_create_order', 'save_custom_billingt_fields', 20, 2 );
function save_custom_billingt_fields( $order, $data ) {
    if ( isset( $_POST['billing_your_name'] ) && ! empty( $_POST['billing_address_3'] ) ) {
        $order->update_meta_data('_checkout_your_name', sanitize_text_field( $_POST['billing_your_name'] ) );
        update_user_meta( $order->get_customer_id(), 'checkout_your_name', sanitize_text_field( $_POST['billing_your_name'] ) );
    }
    if ( isset( $_POST['billing_bank_account_number'] ) && ! empty( $_POST['billing_bank_account_number'] ) ) {
        $order->update_meta_data('_billing_bank_account_number', sanitize_text_field( $_POST['billing_bank_account_number'] ) );
        update_user_meta( $order->get_customer_id(), 'billing_bank_account_number', sanitize_text_field( $_POST['billing_bank_account_number'] ) );
    }
    if ( isset( $_POST['billing_bank_IFSC_code'] ) && ! empty( $_POST['billing_bank_IFSC_code'] ) ) {
        $order->update_meta_data('_billing_bank_IFSC_code', sanitize_text_field( $_POST['billing_bank_IFSC_code'] ) );
        update_user_meta( $order->get_customer_id(), 'billing_bank_IFSC_code', sanitize_text_field( $_POST['billing_bank_IFSC_code'] ) );
    }
    if ( isset( $_POST['billing_your_phone'] ) && ! empty( $_POST['billing_your_phone'] ) ) {
        $order->update_meta_data('_billing_your_phone', sanitize_text_field( $_POST['billing_your_phone'] ) );
        update_user_meta( $order->get_customer_id(), 'billing_your_phone', sanitize_text_field( $_POST['billing_your_phone'] ) );
    }

    if ( isset( $_POST['billing_your_mail'] ) && ! empty( $_POST['billing_your_mail'] ) ) {
        $order->update_meta_data('_billing_your_mail', sanitize_text_field( $_POST['billing_your_mail'] ) );
        update_user_meta( $order->get_customer_id(), 'billing_your_mail', sanitize_text_field( $_POST['billing_your_mail'] ) );
    }

}

/******* Display in emails ********/
add_action( 'woocommerce_email_after_order_table', 'display_new_checkout_fields_in_emails', 20, 4 );
function display_new_checkout_fields_in_emails( $order, $sent_to_admin, $plain_text, $email ) {
    if ( get_post_meta( $order->get_id(), 
	'_billing_your_name', true ) ) 
	  echo '<h3>Customers Details</h3>';
	  echo '<p><strong>Your name:</strong> ' 
	  . get_post_meta( $order->get_id(), '_billing_your_name', true ) . '</p>';
  
   if ( get_post_meta( $order->get_id(), 
	'_billing_bank_account_number', true ) ) echo '<p><strong>Account Number:</strong> ' 
	 . get_post_meta( $order->get_id(), '_billing_bank_account_number', true ) . '</p>';
  
   if ( get_post_meta( $order->get_id(), 
	'_billing_bank_IFSC_code', true ) ) echo '<p><strong>IFSC Code:</strong> ' 
	 . get_post_meta( $order->get_id(), '_billing_bank_IFSC_code', true ) . '</p>';

   if ( get_post_meta( $order->get_id(), 
	'_billing_your_phone', true ) ) echo '<p><strong>Your Phone:</strong> ' 
	 . get_post_meta( $order->get_id(), '_billing_your_phone', true ) . '</p>';

   if ( get_post_meta( $order->get_id(), 
	'_billing_your_mail', true ) ) echo '<p><strong>Your Email:</strong> ' 
	 . get_post_meta( $order->get_id(), '_billing_your_mail', true ) . '</p>';

}


/****** Billing Address title change in checkout page ******/

function wc_billing_field_strings( $translated_text, $text, $domain ) {
switch ( $translated_text ) {
case 'Billing details' :
$translated_text = __( 'Book Now', 'woocommerce' );
break;
}
return $translated_text;
}
add_filter( 'gettext', 'wc_billing_field_strings', 20, 3 );

/********** only one cart items in cart page ***********/

add_filter( 'woocommerce_add_cart_item_data', 'woo_custom_add_to_cart' );

function woo_custom_add_to_cart( $cart_item_data ) {

    global $woocommerce;
    $woocommerce->cart->empty_cart();

    // Do nothing with the data and return
    return $cart_item_data;
}



/************ heads products dropdown *************/

function display_heads_products() {
    // HERE below, define your Product category names
    $term_names = array('heads');

    // The WP_Query
    $query = new WP_Query( array(
        'posts_per_page' => -1,
        'post_type' => 'product',
        'post_status' => 'publish',
        'hide_empty' => 0,
        'orderby' => 'title',
        'tax_query' => array( array(
            'taxonomy' => 'product_cat', // for a Product category (or 'product_tag' for a Product tag)
            'field'    => 'name',        // can be 'name', 'slug' or 'term_id'
            'terms'    => $term_names,
        ) ),
        'echo' => '0'
    ) );

    $output = '<select>';
    // foreach ( $products as $product ) {
    if ( $query->have_posts() ) :
    while ( $query->have_posts() ) : $query->the_post();

        $permalink = get_permalink($query->post->ID);
        $title = $query->post->post_title;
        $output .= '<option value="' . $permalink . '">' . $title . '</option>';

    endwhile;

    wp_reset_postdata();

    $output .='</select>';

    else :

    $output = '<p>No products found<p>';

    endif;

    return $output;
}

add_shortcode( 'display_heads_products', 'display_heads_products' );


/************ tiles products dropdown *************/

function display_tiles_products() {
    // HERE below, define your Product category names
    $term_names = array('tiles');

    // The WP_Query
    $query = new WP_Query( array(
        'posts_per_page' => -1,
        'post_type' => 'product',
        'post_status' => 'publish',
        'hide_empty' => 0,
        'orderby' => 'title',
        'tax_query' => array( array(
            'taxonomy' => 'product_cat', // for a Product category (or 'product_tag' for a Product tag)
            'field'    => 'name',        // can be 'name', 'slug' or 'term_id'
            'terms'    => $term_names,
        ) ),
        'echo' => '0'
    ) );

    $output = '<select>';
    // foreach ( $products as $product ) {
    if ( $query->have_posts() ) :
    while ( $query->have_posts() ) : $query->the_post();

        $permalink = get_permalink($query->post->ID);
        $title = $query->post->post_title;
        $output .= '<option value="' . $permalink . '">' . $title . '</option>';

    endwhile;

    wp_reset_postdata();

    $output .='</select>';

    else :

    $output = '<p>No products found<p>';

    endif;

    return $output;
}

add_shortcode( 'display_tiles_products', 'display_tiles_products' );


/******* rename thank you order details oreder recieved ********/

add_filter( 'woocommerce_thankyou_order_received_text', 'avia_thank_you' );
function avia_thank_you() {
 $added_text = '<p>Thanks for betting !!</p>';
 return $added_text ;
}

/******* rename thank you order details heading ********/

add_filter('gettext', 'changes_in_thank_you', 100, 3 );
function changes_in_thank_you( $translated_text, $text, $domain ) {
    if( $text === 'Order details' ) {

        $translated_text =  __( 'Betting Details', $domain );
    }
    return $translated_text;
}
